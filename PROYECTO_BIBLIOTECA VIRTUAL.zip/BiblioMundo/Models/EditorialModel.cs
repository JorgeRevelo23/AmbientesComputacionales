﻿namespace BiblioMundo.Models
{
    public class EditorialModel 
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public bool Estado { get; set; }
        //public List<LibroModel> libros { get; set; }

    }
}
